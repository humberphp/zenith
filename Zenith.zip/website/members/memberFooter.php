<?php
$headerNav = "<div class='blog-footer'>
      <p> THIS IS A STUDENT PROJECT WEBSITE FOR HUMBER COLLEGE WEB DEV PROGRAM &copy; Team Zenith - All Rights Reserved 2014 </p>
      <p>
        <a href='#'>Back to top</a>
      </p>
    </div>"; 
echo $headerNav;
?>
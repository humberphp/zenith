CREATE DATABASE  IF NOT EXISTS `mysql_65818_matrimony` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mysql_65818_matrimony`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: my02.winhost.com    Database: mysql_65818_matrimony
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_cast`
--

DROP TABLE IF EXISTS `tbl_cast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cast` (
  `castId` int(11) NOT NULL AUTO_INCREMENT,
  `religionId` int(11) NOT NULL,
  `cast` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`castId`),
  KEY `religionId` (`religionId`),
  CONSTRAINT `tbl_cast_ibfk_1` FOREIGN KEY (`castId`) REFERENCES `tbl_religions` (`religionId`),
  CONSTRAINT `tbl_cast_ibfk_2` FOREIGN KEY (`religionId`) REFERENCES `tbl_religions` (`religionId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cast`
--

LOCK TABLES `tbl_cast` WRITE;
/*!40000 ALTER TABLE `tbl_cast` DISABLE KEYS */;
INSERT INTO `tbl_cast` VALUES (1,1,'Ramgharia'),(2,1,'Jatt');
/*!40000 ALTER TABLE `tbl_cast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_city`
--

DROP TABLE IF EXISTS `tbl_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_city` (
  `cityId` int(11) NOT NULL AUTO_INCREMENT,
  `stateId` int(11) NOT NULL,
  `city` varchar(50) NOT NULL,
  PRIMARY KEY (`cityId`),
  KEY `stateId` (`stateId`),
  CONSTRAINT `tbl_city_ibfk_1` FOREIGN KEY (`stateId`) REFERENCES `tbl_state` (`stateId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_city`
--

LOCK TABLES `tbl_city` WRITE;
/*!40000 ALTER TABLE `tbl_city` DISABLE KEYS */;
INSERT INTO `tbl_city` VALUES (1,1,'Brampton'),(2,1,'Mississauge'),(3,1,'Etobicoke'),(4,2,'Camloos'),(5,2,'calgary');
/*!40000 ALTER TABLE `tbl_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_country`
--

DROP TABLE IF EXISTS `tbl_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_country` (
  `countryId` int(11) NOT NULL AUTO_INCREMENT,
  `countryName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`countryId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_country`
--

LOCK TABLES `tbl_country` WRITE;
/*!40000 ALTER TABLE `tbl_country` DISABLE KEYS */;
INSERT INTO `tbl_country` VALUES (1,'Canada'),(2,'USA');
/*!40000 ALTER TABLE `tbl_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_department` (
  `DepartmentId` int(11) NOT NULL AUTO_INCREMENT,
  `Department` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`DepartmentId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_department`
--

LOCK TABLES `tbl_department` WRITE;
/*!40000 ALTER TABLE `tbl_department` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_faqs`
--

DROP TABLE IF EXISTS `tbl_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_faqs` (
  `questionId` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(200) DEFAULT NULL,
  `answer` varchar(500) DEFAULT NULL,
  `topicId` int(11) DEFAULT NULL,
  PRIMARY KEY (`questionId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_faqs`
--

LOCK TABLES `tbl_faqs` WRITE;
/*!40000 ALTER TABLE `tbl_faqs` DISABLE KEYS */;
INSERT INTO `tbl_faqs` VALUES (1,'How to register','Click on register link, fill your information and clickon submit button',1);
/*!40000 ALTER TABLE `tbl_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_faqtopics`
--

DROP TABLE IF EXISTS `tbl_faqtopics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_faqtopics` (
  `topicId` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`topicId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_faqtopics`
--

LOCK TABLES `tbl_faqtopics` WRITE;
/*!40000 ALTER TABLE `tbl_faqtopics` DISABLE KEYS */;
INSERT INTO `tbl_faqtopics` VALUES (1,'Registration');
/*!40000 ALTER TABLE `tbl_faqtopics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_imagerequests`
--

DROP TABLE IF EXISTS `tbl_imagerequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_imagerequests` (
  `imageRequestId` int(11) NOT NULL AUTO_INCREMENT,
  `senderUserId` int(11) DEFAULT NULL,
  `receiverUserId` int(11) DEFAULT NULL,
  `dateSent` date DEFAULT NULL,
  `isViewed` bit(1) DEFAULT NULL,
  PRIMARY KEY (`imageRequestId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_imagerequests`
--

LOCK TABLES `tbl_imagerequests` WRITE;
/*!40000 ALTER TABLE `tbl_imagerequests` DISABLE KEYS */;
INSERT INTO `tbl_imagerequests` VALUES (1,5,6,'2014-02-02','\0');
/*!40000 ALTER TABLE `tbl_imagerequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_membershippaymenthistory`
--

DROP TABLE IF EXISTS `tbl_membershippaymenthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_membershippaymenthistory` (
  `membershipPaymentId` int(11) NOT NULL AUTO_INCREMENT,
  `userMembershipId` int(11) DEFAULT NULL,
  `paymentDate` date DEFAULT NULL,
  `confirmationNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`membershipPaymentId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_membershippaymenthistory`
--

LOCK TABLES `tbl_membershippaymenthistory` WRITE;
/*!40000 ALTER TABLE `tbl_membershippaymenthistory` DISABLE KEYS */;
INSERT INTO `tbl_membershippaymenthistory` VALUES (1,1,'2014-05-05','46216');
/*!40000 ALTER TABLE `tbl_membershippaymenthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_memberships`
--

DROP TABLE IF EXISTS `tbl_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_memberships` (
  `membershipId` int(11) NOT NULL AUTO_INCREMENT,
  `membership` varchar(45) NOT NULL,
  `daysAllowed` int(11) NOT NULL,
  `contactsAllowed` int(11) NOT NULL,
  `price` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`membershipId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_memberships`
--

LOCK TABLES `tbl_memberships` WRITE;
/*!40000 ALTER TABLE `tbl_memberships` DISABLE KEYS */;
INSERT INTO `tbl_memberships` VALUES (1,'Basic',90,50,95.99),(2,'Altra',180,90,150.99);
/*!40000 ALTER TABLE `tbl_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_religions`
--

DROP TABLE IF EXISTS `tbl_religions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_religions` (
  `religionId` int(11) NOT NULL AUTO_INCREMENT,
  `religion` varchar(50) NOT NULL,
  PRIMARY KEY (`religionId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_religions`
--

LOCK TABLES `tbl_religions` WRITE;
/*!40000 ALTER TABLE `tbl_religions` DISABLE KEYS */;
INSERT INTO `tbl_religions` VALUES (1,'Sikh'),(2,'Hindu'),(3,'muslim'),(4,'Christian');
/*!40000 ALTER TABLE `tbl_religions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_roles`
--

DROP TABLE IF EXISTS `tbl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_roles` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(45) NOT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_roles`
--

LOCK TABLES `tbl_roles` WRITE;
/*!40000 ALTER TABLE `tbl_roles` DISABLE KEYS */;
INSERT INTO `tbl_roles` VALUES (1,'Admin'),(2,'Agent'),(3,'User');
/*!40000 ALTER TABLE `tbl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_specialpaymenthistory`
--

DROP TABLE IF EXISTS `tbl_specialpaymenthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_specialpaymenthistory` (
  `specialPaymentId` int(11) NOT NULL AUTO_INCREMENT,
  `userSpeicalId` int(11) DEFAULT NULL,
  `paymentDate` date DEFAULT NULL,
  `confirmationNumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`specialPaymentId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_specialpaymenthistory`
--

LOCK TABLES `tbl_specialpaymenthistory` WRITE;
/*!40000 ALTER TABLE `tbl_specialpaymenthistory` DISABLE KEYS */;
INSERT INTO `tbl_specialpaymenthistory` VALUES (1,1,'2014-02-05','543423');
/*!40000 ALTER TABLE `tbl_specialpaymenthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_specials`
--

DROP TABLE IF EXISTS `tbl_specials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_specials` (
  `specialId` int(11) NOT NULL AUTO_INCREMENT,
  `special` varchar(45) DEFAULT NULL,
  `daysAllowed` int(11) DEFAULT NULL,
  `price` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`specialId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_specials`
--

LOCK TABLES `tbl_specials` WRITE;
/*!40000 ALTER TABLE `tbl_specials` DISABLE KEYS */;
INSERT INTO `tbl_specials` VALUES (1,'Profile Highlighter',2,10.49);
/*!40000 ALTER TABLE `tbl_specials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_state`
--

DROP TABLE IF EXISTS `tbl_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_state` (
  `stateId` int(11) NOT NULL AUTO_INCREMENT,
  `countryId` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY (`stateId`),
  KEY `countryId` (`countryId`),
  CONSTRAINT `tbl_state_ibfk_1` FOREIGN KEY (`countryId`) REFERENCES `tbl_country` (`countryId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_state`
--

LOCK TABLES `tbl_state` WRITE;
/*!40000 ALTER TABLE `tbl_state` DISABLE KEYS */;
INSERT INTO `tbl_state` VALUES (1,1,'ON'),(2,1,'AB');
/*!40000 ALTER TABLE `tbl_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_successstories`
--

DROP TABLE IF EXISTS `tbl_successstories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_successstories` (
  `successStoryId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `isApproved` bit(1) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `submitDate` date DEFAULT NULL,
  `imageName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`successStoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_successstories`
--

LOCK TABLES `tbl_successstories` WRITE;
/*!40000 ALTER TABLE `tbl_successstories` DISABLE KEYS */;
INSERT INTO `tbl_successstories` VALUES (1,5,'','This is story message','2014-05-13','images/imageStory1.jpb');
/*!40000 ALTER TABLE `tbl_successstories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_supporttickets`
--

DROP TABLE IF EXISTS `tbl_supporttickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_supporttickets` (
  `supportTicketId` int(11) NOT NULL AUTO_INCREMENT,
  `senderUserId` int(11) DEFAULT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `submitDate` date DEFAULT NULL,
  `IsClosed` bit(1) DEFAULT NULL,
  `departmentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`supportTicketId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_supporttickets`
--

LOCK TABLES `tbl_supporttickets` WRITE;
/*!40000 ALTER TABLE `tbl_supporttickets` DISABLE KEYS */;
INSERT INTO `tbl_supporttickets` VALUES (1,6,'Memebership','2014-02-02','\0',1);
/*!40000 ALTER TABLE `tbl_supporttickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_supportticketshistory`
--

DROP TABLE IF EXISTS `tbl_supportticketshistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_supportticketshistory` (
  `supportTicketId` int(11) NOT NULL,
  `senderUserId` int(11) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `messageDate` date DEFAULT NULL,
  `agentUserId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_supportticketshistory`
--

LOCK TABLES `tbl_supportticketshistory` WRITE;
/*!40000 ALTER TABLE `tbl_supportticketshistory` DISABLE KEYS */;
INSERT INTO `tbl_supportticketshistory` VALUES (1,3,'Reply','2014-02-03',3),(1,6,'New Question from user','2014-02-03',3),(1,3,'New Reply from agent','2014-02-03',3);
/*!40000 ALTER TABLE `tbl_supportticketshistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userbasicdetails`
--

DROP TABLE IF EXISTS `tbl_userbasicdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userbasicdetails` (
  `userId` int(11) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `age` int(11) NOT NULL DEFAULT '0',
  `dateOfBirth` varchar(50) DEFAULT NULL,
  `createsFor` varchar(50) DEFAULT NULL,
  `aboutUser` varchar(50) DEFAULT NULL,
  `bodyType` varchar(50) DEFAULT NULL,
  `complexion` varchar(50) DEFAULT NULL,
  `physicalStatus` varchar(50) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `motherTounge` varchar(50) DEFAULT NULL,
  `martialStatus` varchar(50) DEFAULT NULL,
  `drinkHabits` varchar(50) DEFAULT NULL,
  `smokeHabits` varchar(50) DEFAULT NULL,
  `eatingHabits` varchar(50) DEFAULT NULL,
  `hairColor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`age`),
  KEY `userId` (`userId`),
  CONSTRAINT `tbl_userbasicdetails_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `tbl_users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userbasicdetails`
--

LOCK TABLES `tbl_userbasicdetails` WRITE;
/*!40000 ALTER TABLE `tbl_userbasicdetails` DISABLE KEYS */;
INSERT INTO `tbl_userbasicdetails` VALUES (6,'F',23,'02/08/1990','sister','This is my sister profile','Slim','Very Fair','Normal',5.3,50,'English','Single','Non-Drinker','Non-Smoker','Non-Veg','White'),(4,'M',33,'09/09/1980','self','This is my profile','Average','Fair','Normal',5.1,95,'Hindi','Single','Social','Social','Non-Veg','Black'),(5,'M',50,'02/08/1975','brother','This is my brothers profile','Average','Fair','Normal',5.3,80,'Punjabi','Single','Social','Non-Smoker','Non-Veg','White');
/*!40000 ALTER TABLE `tbl_userbasicdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userhobbies`
--

DROP TABLE IF EXISTS `tbl_userhobbies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userhobbies` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `hobbies` varchar(500) DEFAULT NULL,
  `interests` varchar(500) DEFAULT NULL,
  `DressStyle` varchar(200) DEFAULT NULL,
  `spokenLanguage` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userhobbies`
--

LOCK TABLES `tbl_userhobbies` WRITE;
/*!40000 ALTER TABLE `tbl_userhobbies` DISABLE KEYS */;
INSERT INTO `tbl_userhobbies` VALUES (4,'reading,writting,gaming','cars,bikes','modern','English,Punjabi,Hindi'),(5,'playing','computers','western','English,Punjabi'),(6,'studying','visiting','western','English');
/*!40000 ALTER TABLE `tbl_userhobbies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userimages`
--

DROP TABLE IF EXISTS `tbl_userimages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userimages` (
  `imageId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `thumbnail` varchar(100) DEFAULT NULL,
  `isMainImage` bit(1) NOT NULL,
  PRIMARY KEY (`imageId`),
  KEY `userId` (`userId`),
  CONSTRAINT `tbl_userimages_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `tbl_users` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userimages`
--

LOCK TABLES `tbl_userimages` WRITE;
/*!40000 ALTER TABLE `tbl_userimages` DISABLE KEYS */;
INSERT INTO `tbl_userimages` VALUES (1,4,'images/image1_big.jpg','images/image1_thumb.jpg',''),(2,5,'images/image2_big.jpg','images/image2_thumb.jpg',''),(3,6,'images/image3_big.jpg','images/image3_thumb.jpg','');
/*!40000 ALTER TABLE `tbl_userimages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userinmembership`
--

DROP TABLE IF EXISTS `tbl_userinmembership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userinmembership` (
  `userMembershipId` int(11) NOT NULL AUTO_INCREMENT,
  `uesrId` int(11) DEFAULT NULL,
  `membershipId` int(11) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `allowedContacts` int(11) DEFAULT NULL,
  `viewedContacts` int(11) DEFAULT NULL,
  PRIMARY KEY (`userMembershipId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userinmembership`
--

LOCK TABLES `tbl_userinmembership` WRITE;
/*!40000 ALTER TABLE `tbl_userinmembership` DISABLE KEYS */;
INSERT INTO `tbl_userinmembership` VALUES (1,4,1,'2014-02-05','2014-05-05',50,15);
/*!40000 ALTER TABLE `tbl_userinmembership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userinspecials`
--

DROP TABLE IF EXISTS `tbl_userinspecials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userinspecials` (
  `userSpecialId` int(11) NOT NULL AUTO_INCREMENT,
  `specialId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  PRIMARY KEY (`userSpecialId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userinspecials`
--

LOCK TABLES `tbl_userinspecials` WRITE;
/*!40000 ALTER TABLE `tbl_userinspecials` DISABLE KEYS */;
INSERT INTO `tbl_userinspecials` VALUES (1,1,4,'2014-02-05','2014-02-07');
/*!40000 ALTER TABLE `tbl_userinspecials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userinteresthistory`
--

DROP TABLE IF EXISTS `tbl_userinteresthistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userinteresthistory` (
  `userInterestId` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `dateSent` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userinteresthistory`
--

LOCK TABLES `tbl_userinteresthistory` WRITE;
/*!40000 ALTER TABLE `tbl_userinteresthistory` DISABLE KEYS */;
INSERT INTO `tbl_userinteresthistory` VALUES (1,4,'Hello','2014-02-12'),(1,6,'What','2014-02-12');
/*!40000 ALTER TABLE `tbl_userinteresthistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userinterests`
--

DROP TABLE IF EXISTS `tbl_userinterests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userinterests` (
  `userInterestId` int(11) NOT NULL AUTO_INCREMENT,
  `receiverUserId` int(11) DEFAULT NULL,
  `senderUserId` int(11) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `dateSent` date DEFAULT NULL,
  `isViewed` bit(1) DEFAULT NULL,
  `IsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`userInterestId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userinterests`
--

LOCK TABLES `tbl_userinterests` WRITE;
/*!40000 ALTER TABLE `tbl_userinterests` DISABLE KEYS */;
INSERT INTO `tbl_userinterests` VALUES (1,6,4,'Hello','2014-02-12','','\0'),(2,5,4,'Hello','2014-02-12','\0','\0');
/*!40000 ALTER TABLE `tbl_userinterests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userlocation`
--

DROP TABLE IF EXISTS `tbl_userlocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userlocation` (
  `userId` int(11) DEFAULT NULL,
  `countryId` int(11) DEFAULT NULL,
  `stateId` int(11) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `citizen` varchar(50) DEFAULT NULL,
  `residentStatus` varchar(50) DEFAULT NULL,
  KEY `userId` (`userId`),
  KEY `countryId` (`countryId`),
  KEY `stateId` (`stateId`),
  KEY `cityId` (`cityId`),
  CONSTRAINT `tbl_userlocation_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `tbl_users` (`userId`),
  CONSTRAINT `tbl_userlocation_ibfk_2` FOREIGN KEY (`countryId`) REFERENCES `tbl_country` (`countryId`),
  CONSTRAINT `tbl_userlocation_ibfk_3` FOREIGN KEY (`stateId`) REFERENCES `tbl_state` (`stateId`),
  CONSTRAINT `tbl_userlocation_ibfk_4` FOREIGN KEY (`cityId`) REFERENCES `tbl_city` (`cityId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userlocation`
--

LOCK TABLES `tbl_userlocation` WRITE;
/*!40000 ALTER TABLE `tbl_userlocation` DISABLE KEYS */;
INSERT INTO `tbl_userlocation` VALUES (4,1,1,1,'Indian','Permanent Resident'),(5,1,2,1,'Indian','Student'),(6,1,1,2,'Canadaian','Citizen');
/*!40000 ALTER TABLE `tbl_userlocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_userprofession`
--

DROP TABLE IF EXISTS `tbl_userprofession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_userprofession` (
  `userId` int(11) NOT NULL,
  `education` varchar(200) NOT NULL DEFAULT '',
  `college` varchar(50) DEFAULT NULL,
  `additionalDegree` varchar(50) DEFAULT NULL,
  `occupation` varchar(50) DEFAULT NULL,
  `employedIn` varchar(50) DEFAULT NULL,
  `annualIncome` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`education`),
  KEY `userId_2` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_userprofession`
--

LOCK TABLES `tbl_userprofession` WRITE;
/*!40000 ALTER TABLE `tbl_userprofession` DISABLE KEYS */;
INSERT INTO `tbl_userprofession` VALUES (6,'Hotel Management','Humber',NULL,'Student','Govt','20000'),(5,'MBA','Punjab College',NULL,'Student','Private','10000'),(4,'MscIT','Humber College','MCA','CEO','Private','60000');
/*!40000 ALTER TABLE `tbl_userprofession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `RoleId` int(11) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `user_role_idx` (`RoleId`),
  CONSTRAINT `user_role` FOREIGN KEY (`RoleId`) REFERENCES `tbl_roles` (`RoleId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (1,'Jagsir','Singh','jagsirsingh@hotmail.com','123456789','jagsir','test123',1),(3,'John','Abraham','john@hotmail.com','123456789','john','test123',2),(4,'Tunde','ABAB','tunde@humber.com','725646','tunde','test123',3),(5,'vikas','sangha','vikas@humber.com','53166','vikas','test123',3),(6,'Alicia','Margareta','alicia@humber.com','5132656','alicia','test123',3);
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_viewedcontacts`
--

DROP TABLE IF EXISTS `tbl_viewedcontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_viewedcontacts` (
  `userId` int(11) DEFAULT NULL,
  `contactId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_viewedcontacts`
--

LOCK TABLES `tbl_viewedcontacts` WRITE;
/*!40000 ALTER TABLE `tbl_viewedcontacts` DISABLE KEYS */;
INSERT INTO `tbl_viewedcontacts` VALUES (4,6),(4,5);
/*!40000 ALTER TABLE `tbl_viewedcontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mysql_65818_matrimony'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-02-15 23:51:33
